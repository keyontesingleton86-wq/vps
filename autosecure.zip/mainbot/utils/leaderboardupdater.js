const { queryParams } = require("../../db/database");
const shorten = require("../../autosecure/utils/utils/shorten");
const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle
} = require("discord.js");

/* =========================
   CONFIG
========================= */
const EMBED_COLOR = 0xB8D2F0;
const MAX_ENTRIES = 10;
const REFRESH_INTERVAL = 2 * 60 * 1000; // 2 minutes

const THUMBNAIL =
  "https://cdn.discordapp.com/attachments/1465727971829485865/1465729852412924014/IMG_0219.png?ex=698f42cc&is=698df14c&hm=d99767b91ca0c7f738d414409754cfdeb69aceb822d8039e47ac6124ecd0b498";

const LINE = "━━━━━━━━━━━━━━━━━━━━━━━━━━━━";

/* =========================
   HELPERS
========================= */
async function checkhidden(userid) {
  const entry = await queryParams(
    `SELECT showleaderboard FROM settings WHERE user_id = ?`,
    [userid]
  );
  if (!entry.length) return false;
  return entry[0].showleaderboard === 0 || entry[0].showleaderboard === "0";
}

function getRankEmoji(index) {
  if (index === 0) return "🥇";
  if (index === 1) return "🥈";
  if (index === 2) return "🥉";
  return `#${index + 1}`;
}

/* =========================
   MESSAGE ID STORAGE
========================= */
async function updatemessageid(id, channelId) {
  const value = `${id}|${channelId}`;

  const existing = await queryParams(
    `SELECT id FROM controlbot WHERE id = ?`,
    [1]
  );

  if (existing.length) {
    await queryParams(
      `UPDATE controlbot SET leaderboardid = ? WHERE id = ?`,
      [value, 1]
    );
  } else {
    await queryParams(
      `INSERT INTO controlbot (id, leaderboardid) VALUES (?, ?)`,
      [1, value]
    );
  }
}

async function getMessageId() {
  const data = await queryParams(
    `SELECT leaderboardid FROM controlbot WHERE id = 1`
  );
  return data[0]?.leaderboardid ?? null;
}

/* =========================
   EMBED GENERATION
========================= */
async function generateLeaderboardEmbeds() {
  try {
    const countLeaderboard = await queryParams(
      `SELECT user_id, amount FROM leaderboard ORDER BY amount DESC LIMIT ?`,
      [MAX_ENTRIES]
    );

    const networthLeaderboard = await queryParams(
      `SELECT user_id, networth FROM leaderboard ORDER BY networth DESC LIMIT ?`,
      [MAX_ENTRIES]
    );

    let countLines = [];
    let networthLines = [];

    for (let i = 0; i < countLeaderboard.length; i++) {
      const row = countLeaderboard[i];
      const hidden = await checkhidden(row.user_id);
      const user = hidden ? "`Hidden User`" : `<@${row.user_id}>`;

      countLines.push(
        `${getRankEmoji(i)} ${user}\n> Secured **${row.amount.toLocaleString()}** accounts`
      );
    }

    for (let i = 0; i < networthLeaderboard.length; i++) {
      const row = networthLeaderboard[i];
      const hidden = await checkhidden(row.user_id);
      const user = hidden ? "`Hidden User`" : `<@${row.user_id}>`;

      networthLines.push(
        `${getRankEmoji(i)} ${user}\n> Networth **${shorten(row.networth)}**`
      );
    }

    const leaderboardEmbed = new EmbedBuilder()
      .setColor(EMBED_COLOR)
      .setThumbnail(THUMBNAIL)
      .setDescription(
        `## :fire: AutoSecure — Accounts Leaderboard\n` +
        `${LINE}\n\n` +
        (countLines.length ? countLines.join("\n\n") : "*No data available*") +
        `\n\n${LINE}`
      );

    const networthEmbed = new EmbedBuilder()
      .setColor(EMBED_COLOR)
      .setThumbnail(THUMBNAIL)
      .setDescription(
        `## :money_mouth: AutoSecure — Networth Leaderboard\n` +
        `${LINE}\n\n` +
        (networthLines.length ? networthLines.join("\n\n") : "*No data available*") +
        `\n\n${LINE}`
      );

    return {
      content: `🕒 **Last Updated:** <t:${Math.floor(Date.now() / 1000)}:R>`,
      embeds: [leaderboardEmbed, networthEmbed],
      components: [
        new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId("hideleaderboard")
            .setLabel("Hide Me")
            .setStyle(ButtonStyle.Secondary)
        )
      ]
    };
  } catch (error) {
    console.error("Leaderboard generation Vortex:", error);
    return { content: "❌ Failed to generate leaderboard." };
  }
}

/* =========================
   MESSAGE EDITOR
========================= */
async function editExistingMessage(client, rawId, content) {
  const [messageId, channelId] = rawId.split("|");

  const channel = await client.channels.fetch(channelId).catch(() => null);
  if (!channel) return false;

  const message = await channel.messages.fetch(messageId).catch(() => null);
  if (!message) return false;

  await message.edit(content);
  return true;
}

/* =========================
   UPDATER LOOP
========================= */
async function updateLeaderboardMessage(client) {
  try {
    const rawId = await getMessageId();
    if (!rawId) return;

    const content = await generateLeaderboardEmbeds();
    await editExistingMessage(client, rawId, content);
  } catch (error) {
    console.error("Leaderboard update failed:", error);
  }
}

async function startLeaderboardUpdater(client) {
  await updateLeaderboardMessage(client);

  const interval = setInterval(
    () => updateLeaderboardMessage(client),
    REFRESH_INTERVAL
  );

  return () => clearInterval(interval);
}

module.exports = {
  startLeaderboardUpdater,
  getMessageId,
  generateLeaderboardEmbeds,
  updatemessageid
};
