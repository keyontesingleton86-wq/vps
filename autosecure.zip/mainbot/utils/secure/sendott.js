module.exports = async function sendott(secId){
return null;
}