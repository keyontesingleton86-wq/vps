const invoicesMap = new Map();

module.exports = {
    invoicesMap
};
