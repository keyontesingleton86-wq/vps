const {
    SectionBuilder,
    TextDisplayBuilder,
    ThumbnailBuilder,
} = require("discord.js");

/**
 * Returns a CV2 SectionBuilder
 * Text on left, avatar on right (thumbnail accessory)
 */
function simpleContainer(member, content) {
    return new SectionBuilder()
        .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(content)
        )
        .setThumbnailAccessory(
            new ThumbnailBuilder().setURL(
                member.user.displayAvatarURL({
                    extension: "png",
                    size: 256,
                })
            )
        );
}

module.exports = { simpleContainer };
