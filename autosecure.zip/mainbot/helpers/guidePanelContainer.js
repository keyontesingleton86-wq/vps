// mainbot/helpers/guidePanelContainer.js

const {
  ContainerBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require("discord.js");

const { serverContainer } = require("./serverContainer");

function buildGuidePanel(guild) {
  const container = new ContainerBuilder();

  // ✅ SECTION — SAME STRUCTURE AS WELCOME
  container.addSectionComponents(
    ...serverContainer(
      guild,
      "**🛡️ AutoSecure Guide Panel**\n" +
        "Use the buttons below to learn more about AutoSecure.\n" +
        "If you still need help, open a ticket."
    )
  );

  // Divider
  container.addSeparatorComponents(
    new SeparatorBuilder()
      .setDivider(true)
      .setSpacing(SeparatorSpacingSize.Small)
  );

  // Buttons
  container.addActionRowComponents(
    new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId("starting_bot")
        .setLabel("Full Setup Guide")
        .setStyle(ButtonStyle.Primary),

      new ButtonBuilder()
        .setCustomId("securing")
        .setLabel("Securing")
        .setStyle(ButtonStyle.Primary),

      new ButtonBuilder()
        .setCustomId("responses")
        .setLabel("Bot Responses")
        .setStyle(ButtonStyle.Primary),

      new ButtonBuilder()
        .setCustomId("login_msauth")
        .setLabel("MSAUTH Login")
        .setStyle(ButtonStyle.Primary)
    )
  );

  return container;
}

module.exports = { buildGuidePanel };
