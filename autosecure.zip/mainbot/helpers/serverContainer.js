// mainbot/helpers/serverContainer.js

const { ThumbnailBuilder, TextDisplayBuilder } = require("discord.js");

/**
 * Builds a section exactly like simpleContainer,
 * but using the SERVER icon instead of a user avatar.
 */
function serverContainer(guild, text) {
  const icon =
    guild.iconURL({ size: 256, extension: "png" }) ||
    "https://cdn.discordapp.com/attachments/1465727971829485865/1465729852412924014/IMG_0219.png?ex=698f42cc&is=698df14c&hm=d99767b91ca0c7f738d414409754cfdeb69aceb822d8039e47ac6124ecd0b498";

  return [
    new ThumbnailBuilder().setURL(icon),
    new TextDisplayBuilder().setContent(text),
  ];
}

module.exports = { serverContainer };
