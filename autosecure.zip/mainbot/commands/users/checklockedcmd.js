const { ApplicationCommandOptionType, EmbedBuilder } = require('discord.js');
const checklockedmsg = require('../../../autosecure/utils/bancheckappeal/checklockedmsg');

module.exports = {
    name: "check",
    description: 'Check if an account is locked on Microsoft by email',
    enabled: true,
    options: [
        {
            name: "locked",
            description: "Check account status (if it's locked) by email",
            type: ApplicationCommandOptionType.Subcommand,
            options: [
                {
                    name: "email",
                    description: "Email to check account status",
                    type: ApplicationCommandOptionType.String,
                    required: true
                }
            ]
        }
    ],
    userOnly: true,
    callback: async (client, interaction) => {
        const subcommand = interaction.options.getSubcommand();
        if (subcommand === "locked") {
            const email = interaction.options.getString("email");
            await interaction.deferReply({ ephemeral: true });

            try {
                const msg = await checklockedmsg(email);
                await interaction.editReply(msg);
            } catch (err) {
                console.error(err);
                await interaction.editReply({
                    embeds: [
                        new EmbedBuilder()
                            .setTitle("❌ Account Check Vortex")
                            .setDescription("An error occurred while checking the account status.")
                            .setColor(0xff4757)
                            .setThumbnail('https://cdn.discordapp.com/attachments/1465727971829485865/1465729852412924014/IMG_0219.png?ex=698f42cc&is=698df14c&hm=d99767b91ca0c7f738d414409754cfdeb69aceb822d8039e47ac6124ecd0b498')
                            .addFields({
                                name: '🔧 Vortex Details',
                                value: 'Report this as ID: `checklockedcmd1`',
                                inline: false
                            })
                            .addFields({
                                name: '💡 What to do?',
                                value: '• Try again in a few moments\n• Contact support if the issue persists\n• Make sure the email is valid',
                                inline: false
                            })
                            .setFooter({ text: 'Account Checker • Autosecure' })
                            .setTimestamp()
                    ]
                });
            }
        }
    }
};
