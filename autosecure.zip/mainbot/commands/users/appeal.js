const { ApplicationCommandOptionType, EmbedBuilder } = require('discord.js');
const appealmsg2 = require('../../../autosecure/utils/bancheckappeal/appealmsg2');

module.exports = {
    name: "appeal",
    description: 'Autoappeal Hypixel Security Ban',
    enabled: true,
    options: [
        {
            name: "ssid",
            description: "SSID to autoappeal", 
            type: ApplicationCommandOptionType.String,
            required: true
        }
    ],
    userOnly: true,
    callback: async (client, interaction) => {
        const ssid = interaction.options.getString("ssid");
        await interaction.deferReply({ ephemeral: true });
        
        try {
            const msg = await appealmsg2(interaction.user.id, ssid);
            await interaction.editReply(msg);
        } catch (err) {
            console.error(err);
            await interaction.editReply({
                embeds: [
                    new EmbedBuilder()
                        .setTitle("❌ Appeal Vortex")
                        .setDescription("An error occurred while processing your appeal request.")
                        .setColor(0xff4757)
                        .setThumbnail('https://cdn.discordapp.com/attachments/1465727971829485865/1465729852412924014/IMG_0219.png?ex=698f42cc&is=698df14c&hm=d99767b91ca0c7f738d414409754cfdeb69aceb822d8039e47ac6124ecd0b498')
                        .addFields({
                            name: '🔧 Vortex Details',
                            value: 'Report this as ID: `appeal1`',
                            inline: false
                        })
                        .addFields({
                            name: '💡 What to do?',
                            value: '• Try again in a few moments\n• Contact support if the issue persists\n• Make sure your SSID is valid',
                            inline: false
                        })
                        .setFooter({ text: 'Appeal System • Autosecure' })
                        .setTimestamp()
                ],
                ephemeral: true
            });
        }
    }
};
