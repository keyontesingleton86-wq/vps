const access = require("../../../db/access");
const { queryParams } = require("../../../db/database");
const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle
} = require("discord.js");
const config = require("../../../config.json");
const generate = require("../../../autosecure/utils/generate");
const { roleid, guildid } = require("../../../config.json");
const { autosecurelogs } = require("../../../autosecure/utils/embeds/autosecurelogs");

module.exports = {
  name: "trial",
  description: `Get a temporary trial to Autosecure!`,

  callback: async (client, interaction) => {
    try {
      await interaction.deferReply({ ephemeral: true });

      let hasAccess = await access(interaction.user.id);
      if (hasAccess) {
        return interaction.editReply({
          content: "You already have access to Autosecure!"
        });
      }

      const trialCheck = await queryParams(
        "SELECT trial FROM trial WHERE user_id = ?",
        [interaction.user.id]
      );

      // ===== Already used trial (UNCHANGED LOGIC) =====
      if (trialCheck.length > 0 && trialCheck[0].trial === "true") {
        const embed = new EmbedBuilder()
          .setColor(0xffb020)
          .setTitle("⚠ Trial already used")
          .setDescription(
            [
              "You already claimed a **trial** (or previously had access).",
              "",
              "━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
              "**What you can do now:**",
              `• Buy a license: **${config.shoplink}**`,
              "• After purchase: use `/redeem` to redeem your key",
              "• Read the full setup in **#guide**",
              "",
              "💡 If you think this is wrong, contact staff."
            ].join("\n")
          )
          .setThumbnail(client.user.displayAvatarURL({ size: 256 }))
          .setFooter({ text: "Vortex AutoSecure • Trial System" })
          .setTimestamp();

        const button = new ButtonBuilder()
          .setLabel("Buy license")
          .setStyle(ButtonStyle.Link)
          .setURL(config.shoplink);

        const button2 = new ButtonBuilder()
          .setLabel("Join Server")
          .setCustomId("joinserver")
          .setStyle(ButtonStyle.Primary);

        const row = new ActionRowBuilder().addComponents(button, button2);

        return interaction.editReply({
          embeds: [embed],
          components: [row],
          ephemeral: true
        });
      }

      // ===== Trial creation (UNCHANGED LOGIC) =====
      const MS_PER_H = 3600000;
      const durationMs = parseInt(config.trial) * MS_PER_H;
      const expiry = Date.now() + durationMs;
      const key = `${config.footer1}-${generate(16)}`;

      await queryParams(
        "INSERT INTO usedLicenses(license, user_id, expiry, one_day_warning_sent, seven_day_warning_sent, istrial) VALUES(?, ?, ?, 0, 0, 1)",
        [key, interaction.user.id, expiry.toString()]
      );

      await queryParams("INSERT INTO autosecure(user_id) VALUES(?)", [
        interaction.user.id
      ]);

      await queryParams("INSERT INTO secureconfig(user_id) VALUES(?)", [
        interaction.user.id
      ]);

      const existingtrial = await queryParams(
        "SELECT * FROM trial WHERE user_id = ?",
        [interaction.user.id]
      );

      if (existingtrial.length > 0) {
        await queryParams("UPDATE trial SET trial = ? WHERE user_id = ?", [
          "true",
          interaction.user.id
        ]);
      } else {
        await queryParams("INSERT INTO trial (user_id, trial) VALUES (?, ?)", [
          interaction.user.id,
          "true"
        ]);
      }

      const slots = await queryParams("SELECT slots FROM slots WHERE user_id = ?", [
        interaction.user.id
      ]);

      if (slots && slots.length > 0) {
        await queryParams("UPDATE slots SET slots = ? WHERE user_id = ?", [
          1,
          interaction.user.id
        ]);
      } else {
        await queryParams("INSERT INTO slots(user_id, slots) VALUES(?, ?)", [
          interaction.user.id,
          1
        ]);
      }

      const expiryTimestamp = Math.floor(expiry / 1000);
      const hourstime = Math.round(parseInt(config.trial));

      // ===== Premium DM embed (UI ONLY) =====
      const embed = new EmbedBuilder()
        .setColor(0x6aa6ff)
        .setTitle("✅ Trial Activated — Vortex AutoSecure")
        .setDescription(
          [
            `You have been granted a **${hourstime} hour** trial.`,
            "",
            "━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
            "**Trial Details**",
            `• **Status:** Active`,
            `• **Expires:** <t:${expiryTimestamp}:R>`,
            `• **User:** <@${interaction.user.id}>`,
            "",
            "━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
            "**Next Steps**",
            "1) Use `/redeem` to redeem your key",
            "2) Open **#guide** and follow the setup",
            "3) Configure your bot settings and start using AutoSecure",
            "",
            "⚠ Abuse = permanent blacklist."
          ].join("\n")
        )
        .setThumbnail(client.user.displayAvatarURL({ size: 256 }))
        .setFooter({ text: "Powered by Vortex & Vortex" })
        .setTimestamp();

      try {
        await autosecurelogs(client, "trial", interaction.user.id, null, null, null, expiryTimestamp);
        await interaction.user.send({ embeds: [embed] });
      } catch (dmError) {
        console.error("Could not DM user:", dmError);
        await interaction.editReply({
          content: `**You've been granted a ${hourstime}h trial!**\nExpires: <t:${expiryTimestamp}:R>`,
          ephemeral: true
        });
        return;
      }

      try {
        const guild = await client.guilds.fetch(guildid);
        const member = await guild.members.fetch(interaction.user.id);
        await member.roles.add(roleid);
      } catch (roleError) {
        console.error("Vortex assigning role:", roleError);
      }

      await interaction.editReply({
        content: `You've been granted a ${hourstime}h trial! Check your DMs for details.`,
        ephemeral: true
      });

    } catch (error) {
      console.error("Error in trial command:", error);
      if (interaction.deferred || interaction.replied) {
        await interaction.editReply({
          content: "An error occurred while processing your trial request",
          ephemeral: true
        });
      } else {
        await interaction.reply({
          content: "An error occurred while processing your trial request",
          ephemeral: true
        });
      }
    }
  }
};
