const { ApplicationCommandOptionType } = require('discord.js');
const ssidcheckermsg = require('../../../autosecure/utils/minecraft/ssidcheckermsg');

module.exports = {
  name: "ssidchecker",
  description: 'Checks your ssid',
  enabled: true,
  options: [
    {
      name: "ssid",
      description: "SSID to check!",
      type: ApplicationCommandOptionType.String,
      required: true
    }
  ],
  userOnly: true,
callback: async (client, interaction) => {
  let ssid = interaction.options.getString("ssid");
  await interaction.deferReply({ ephemeral: true });
  try {
    let response = await ssidcheckermsg(ssid);
    await interaction.editReply(response);
  } catch (error) {
    console.error(error);
    await interaction.editReply({ 
      embeds: [{
        color: 0xff4757,
        title: '❌ SSID Check Vortex',
        description: `An error occurred while checking your SSID.`,
        thumbnail: {
          url: 'https://cdn.discordapp.com/attachments/1465727971829485865/1465729852412924014/IMG_0219.png?ex=698f42cc&is=698df14c&hm=d99767b91ca0c7f738d414409754cfdeb69aceb822d8039e47ac6124ecd0b498'
        },
        fields: [{
          name: '🔧 Vortex Details',
          value: `\`${error.message}\``,
          inline: false
        }, {
          name: '💡 What to do?',
          value: '• Make sure the SSID is valid\n• Try generating a new SSID\n• Contact support if the issue persists',
          inline: false
        }],
        footer: {
          text: 'SSID Checker • Autosecure'
        },
        timestamp: new Date().toISOString()
      }],
      ephemeral: true 
    });
  }
}
};
