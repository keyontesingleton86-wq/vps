const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle
} = require("discord.js");

module.exports = {
  name: "buypanel",
  description: "Send the official Vortex AutoSecure purchase panel",
  userOnly: true, // prevents bot spam
  options: [],

  callback: async (client, interaction) => {
    try {
      await interaction.deferReply({ ephemeral: true });

      const embed = new EmbedBuilder()
        .setColor(0x6aa6ff)
        .setTitle("🛡 Vortex AutoSecure — Official Purchase Panel")
        .setDescription(
          "**Enterprise-grade automated security & exploitation platform.**\n\n" +
          "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
          "**🔐 What is AutoSecure?**\n" +
          "• Microsoft & Minecraft account takeover\n" +
          "• OTP + OAuth phishing automation\n" +
          "• SSID extraction & session hijacking\n" +
          "• Account intelligence & networth tracking\n" +
          "• Mass automation & claiming systems\n\n" +
          "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
          "**🛒 How To Purchase**\n" +
          "1. Click **Buy Now** below\n" +
          "2. Complete purchase\n" +
          "3. Use `/redeem` to redeem your key\n" +
          "4. Follow **#guide** channel instructions\n\n" +
          "**🌐 Website:** https://vortexsec.mysellauth.com"
        )
        .setThumbnail("https://cdn.discordapp.com/attachments/1465727971829485865/1465729852412924014/IMG_0219.png?ex=698f42cc&is=698df14c&hm=d99767b91ca0c7f738d414409754cfdeb69aceb822d8039e47ac6124ecd0b498")
        .setImage("https://cdn.discordapp.com/attachments/1465727971829485865/1465729852412924014/IMG_0219.png?ex=698f42cc&is=698df14c&hm=d99767b91ca0c7f738d414409754cfdeb69aceb822d8039e47ac6124ecd0b498")
        .addFields(
          {
            name: "💳 Pricing",
            value:
              "• **Monthly License:** `$3`\n" +
              "• **Server Slot:** `$4`\n" +
              "• **Lifetime Key:** `$10`",
            inline: false
          },
          {
            name: "⚡ Why Choose Vortex AutoSecure?",
            value:
              "• Ultra-fast exploit pipelines\n" +
              "• High-success phishing automation\n" +
              "• Massive claiming throughput\n" +
              "• Advanced account intelligence\n" +
              "• Discord enterprise dashboards\n" +
              "• Full automation system",
            inline: false
          }
        )
        .setFooter({ text: "Powered By SeriesV2" })
        .setTimestamp();

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setLabel("🛒 Buy Now")
          .setStyle(ButtonStyle.Link)
          .setURL("https://vortexsec.mysellauth.com"),

        new ButtonBuilder()
          .setLabel("💲 View Prices")
          .setStyle(ButtonStyle.Link)
          .setURL("https://vortexsec.mysellauth.com"),

        new ButtonBuilder()
          .setLabel("🌐 Website")
          .setStyle(ButtonStyle.Link)
          .setURL("http://vortexsec.mysellauth.com")
      );

      await interaction.channel.send({
        embeds: [embed],
        components: [row]
      });

      await interaction.editReply({
        content: "✅ Buy panel sent.",
        ephemeral: true
      });

    } catch (err) {
      console.error("BuyPanel Vortex:", err);
      await interaction.editReply({
        content: "❌ Failed to send buy panel.",
        ephemeral: true
      });
    }
  }
};
