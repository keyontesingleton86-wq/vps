const { queryParams } = require("../../../db/database"); 
const hasAccess = require("../../../db/access");
const { discordServer, footer1 } = require("../../../config.json");
const isOwner = require("../../../db/isOwner");

const THUMBNAIL = "https://cdn.discordapp.com/attachments/1465727971829485865/1465729852412924014/IMG_0219.png?ex=698f42cc&is=698df14c&hm=d99767b91ca0c7f738d414409754cfdeb69aceb822d8039e47ac6124ecd0b498";
const BANNER = "https://cdn.discordapp.com/attachments/1465727971829485865/1465729852412924014/IMG_0219.png?ex=698f42cc&is=698df14c&hm=d99767b91ca0c7f738d414409754cfdeb69aceb822d8039e47ac6124ecd0b498";

module.exports = {
    name: "license",
    userOnly: true,
    description: "View your AutoSecure license & stats",
    options: [
        {
            name: "user_id",
            description: "View license info for a user (Owner only)",
            type: 3,
            required: false
        }
    ],
    callback: async (client, interaction) => {
        try {
            let entered = await interaction.options.getString("user_id");

            if (!entered || !await isOwner(interaction.user.id)) {
                await interaction.deferReply({ ephemeral: true });

                const userId = interaction.user.id;
                const access = await hasAccess(userId);

                if (!access) {
                    return interaction.editReply({
                        content: `🚫 You don't own a license!\nJoin ${discordServer} to purchase one.`
                    });
                }

                const info = await queryParams(
                    `SELECT * FROM usedLicenses WHERE user_id=?`,
                    [userId]
                );

                if (!info || !info.length) {
                    return interaction.editReply({
                        content: "⚠️ License record not found."
                    });
                }

                const slots = await queryParams(
                    `SELECT * FROM slots WHERE user_id=?`,
                    [userId]
                );

                const leaderboard = await queryParams(
                    `SELECT * FROM leaderboard WHERE user_id=?`,
                    [userId]
                );

                const expiryEpoch = Math.floor(info[0].expiry / 1000);
                const expires = `<t:${expiryEpoch}:R>`;

                const amount = leaderboard?.[0]?.amount ?? 0;
                const networth = leaderboard?.[0]?.networth ?? 0;
                const botSlots = slots?.[0]?.slots ?? 0;

                const embed = {
                    color: 0x6aa6ff,
                    title: "🔐 Your License Dashboard",
                    description:
                        "**Vortex AutoSecure — Enterprise Security System**\n\n" +
                        "Below is your current license status and security metrics.",
                    thumbnail: { url: THUMBNAIL },
                    image: { url: BANNER },
                    fields: [
                        { name: "📦 Product", value: info[0].istrial ? "Trial Access" : "AutoSecure Monthly", inline: true },
                        { name: "🧩 Bot Slots", value: String(botSlots), inline: true },
                        { name: "⏳ Expires", value: expires, inline: true },

                        { name: "🔑 License Key", value: `\`${info[0].license}\``, inline: false },

                        { name: "🛡 Accounts Secured", value: amount.toLocaleString(), inline: true },
                        { name: "💰 Total Networth", value: networth.toLocaleString(), inline: true },
                        { name: "📊 Usage Tier", value: amount > 1000 ? "🔥 Elite" : "⚡ Standard", inline: true }
                    ],
                    footer: { text: footer1 },
                    timestamp: new Date().toISOString()
                };

                return interaction.editReply({
                    embeds: [embed],
                    ephemeral: true
                });
            }

            /* ========== ADMIN VIEW ========== */

            await interaction.deferReply({ ephemeral: true });

            let targetUserId = entered;

            const licenseCheck = await queryParams(
                `SELECT * FROM usedLicenses WHERE license = ? OR user_id = ?`,
                [entered, entered]
            );

            if (!licenseCheck || !licenseCheck.length) {
                return interaction.editReply({
                    content: "❌ User or license not found."
                });
            }

            targetUserId = licenseCheck[0].user_id;

            const slots = await queryParams(`SELECT * FROM slots WHERE user_id=?`, [targetUserId]);
            const leaderboard = await queryParams(`SELECT * FROM leaderboard WHERE user_id=?`, [targetUserId]);

            const expiryEpoch = Math.floor(licenseCheck[0].expiry / 1000);
            const expires = `<t:${expiryEpoch}:R>`;

            const amount = leaderboard?.[0]?.amount ?? 0;
            const networth = leaderboard?.[0]?.networth ?? 0;
            const botSlots = slots?.[0]?.slots ?? 0;

            const embed = {
                color: 0xa855ff,
                title: "🛠 License Information — Admin View",
                thumbnail: { url: THUMBNAIL },
                image: { url: BANNER },
                fields: [
                    { name: "👤 User", value: `<@${targetUserId}>\n\`${targetUserId}\``, inline: false },

                    { name: "📦 Product", value: licenseCheck[0].istrial ? "Trial" : "Monthly", inline: true },
                    { name: "🧩 Bot Slots", value: String(botSlots), inline: true },
                    { name: "⏳ Expires", value: expires, inline: true },

                    { name: "🔑 License", value: `\`${licenseCheck[0].license}\``, inline: false },

                    { name: "🛡 Secured", value: amount.toLocaleString(), inline: true },
                    { name: "💰 Networth", value: networth.toLocaleString(), inline: true },
                    { name: "⚙ Status", value: "🟢 Active", inline: true }
                ],
                footer: { text: footer1 },
                timestamp: new Date().toISOString()
            };

            return interaction.editReply({
                embeds: [embed],
                ephemeral: true
            });

        } catch (err) {
            console.error("License Command Vortex:", err);
            return interaction.editReply({
                content: "❌ Failed to fetch license info. Please try again."
            });
        }
    }
};
