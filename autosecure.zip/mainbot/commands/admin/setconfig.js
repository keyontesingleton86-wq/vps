const { ApplicationCommandOptionType, EmbedBuilder } = require('discord.js');
const { owners } = require('../../../config.json');
const fs = require('fs');
const path = require('path');

const isOwner = async (userId) => {
    return owners.includes(userId);
};

module.exports = {
    name: 'setconfig',
    description: '⚙️ Set individual configuration values',
    type: 1,
    options: [
        {
            name: 'channel',
            description: 'Set a channel configuration',
            type: ApplicationCommandOptionType.Subcommand,
            options: [
                {
                    name: 'type',
                    description: 'The type of channel to set',
                    type: ApplicationCommandOptionType.String,
                    required: true,
                    choices: [
                        { name: 'Welcome Channel', value: 'welcomechannel' },
                        { name: 'Leaderboard Channel', value: 'leaderboard' },
                        { name: 'Log Channel', value: 'log' },
                        { name: 'Notifier Channel', value: 'notifierChannel' },
                        { name: 'Ticket Category', value: 'ticketcategory' }
                    ]
                },
                {
                    name: 'channel',
                    description: 'The channel to set',
                    type: ApplicationCommandOptionType.Channel,
                    required: true
                }
            ]
        },
        {
            name: 'role',
            description: 'Set a role configuration',
            type: ApplicationCommandOptionType.Subcommand,
            options: [
                {
                    name: 'type',
                    description: 'The type of role to set',
                    type: ApplicationCommandOptionType.String,
                    required: true,
                    choices: [
                        { name: 'Member Role', value: 'memberrole' },
                        { name: 'Role ID', value: 'roleid' }
                    ]
                },
                {
                    name: 'role',
                    description: 'The role to set',
                    type: ApplicationCommandOptionType.Role,
                    required: true
                }
            ]
        },
        {
            name: 'value',
            description: 'Set a value configuration',
            type: ApplicationCommandOptionType.Subcommand,
            options: [
                {
                    name: 'type',
                    description: 'The type of value to set',
                    type: ApplicationCommandOptionType.String,
                    required: true,
                    choices: [
                        { name: 'Notifier Webhook', value: 'notifierwebhook' },
                        { name: 'Guild ID', value: 'guildid' }
                    ]
                },
                {
                    name: 'value',
                    description: 'The value to set',
                    type: ApplicationCommandOptionType.String,
                    required: true
                }
            ]
        }
    ],

    execute: async (client, interaction) => {
        if (!await isOwner(interaction.user.id)) {
            return interaction.reply({
                content: 'You do not have permission to use this command.',
                ephemeral: true,
            });
        }

        const subcommand = interaction.options.getSubcommand();
        const configPath = path.join(__dirname, '../../../config.json');
        const config = require(configPath);

        let replyMessage = '';

        if (subcommand === 'channel') {
            const channelType = interaction.options.getString('type');
            const channel = interaction.options.getChannel('channel');
            config[channelType] = channel.id;
            replyMessage = `Successfully set \`${channelType}\` to \`${channel.name}\` (${channel.id}).`;
        } else if (subcommand === 'role') {
            const roleType = interaction.options.getString('type');
            const role = interaction.options.getRole('role');
            config[roleType] = role.id;
            replyMessage = `Successfully set \`${roleType}\` to \`${role.name}\` (${role.id}).`;
        } else if (subcommand === 'value') {
            const valueType = interaction.options.getString('type');
            const value = interaction.options.getString('value');
            config[valueType] = value;
            replyMessage = `Successfully set \`${valueType}\` to \`${value}\`.`;
        }

        fs.writeFileSync(configPath, JSON.stringify(config, null, 2));

        const embed = new EmbedBuilder()
            .setColor(0x00FF00)
            .setTitle('Configuration Updated')
            .setDescription(replyMessage)
            .setTimestamp();

        await interaction.reply({ embeds: [embed], ephemeral: true });
    },
};