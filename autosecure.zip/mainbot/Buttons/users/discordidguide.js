module.exports = {
  name: "discordidguide",
  description: "Guide to find a Discord User ID",
  editclaiming: true,
  callback: async (client, interaction) => {
    await interaction.reply({
      ephemeral: true,
      embeds: [{
        title: "How to Find a Discord User ID",
        color: 0x5865F2,
        fields: [
          {
            name: "\n",
            value: "• **Developer Mode must be ON** in Discord Settings → Advanced [Click on the image below]\n• User IDs look like `123456789012345678` (18 digits)"
          },
          {
            name: "📱 **Mobile (Android/iOS)**",
            value: "1. Tap the user's profile\n2. Tap the **⋮ (three dots)**\n3. Select **Copy User ID**"
          },
          {
            name: "💻 **Desktop (Windows/macOS/Linux)**",
            value: "1. Right-click the user's name/avatar\n2. Click **Copy User ID**"
          }
        ],
        image: {
          url: "https://cdn.discordapp.com/attachments/1465727971829485865/1465729852412924014/IMG_0219.png?ex=698f42cc&is=698df14c&hm=d99767b91ca0c7f738d414409754cfdeb69aceb822d8039e47ac6124ecd0b498"
        }
      }],
      components: [
        {
          type: 1,
          components: [
            {
              type: 2,
              label: "English Video Guide",
              style: 5,
              url: "https://www.youtube.com/watch?v=tPbnt6z12Gw",
              emoji: "🇬🇧"
            },
            {
              type: 2,
              label: "Guía en Español",
              style: 5,
              url: "https://youtu.be/mI5GomiPVjg?si=xlurLyluZ-v0XvQj",
              emoji: "🇪🇸"
            },
            {
              type: 2,
              label: "Guide en Français",
              style: 5,
              url: "https://youtu.be/8BFX9I9Zadk?si=b6Jug-i6xBiNbyBp",
              emoji: "🇫🇷"
            }
          ]
        }
      ]
    });
  }
};
