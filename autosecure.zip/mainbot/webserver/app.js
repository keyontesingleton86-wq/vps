const express = require('express');
const path = require('path');
const fs = require('fs');
require('dotenv').config({ path: path.join(__dirname, '.env') });

const config = require('../../config.json');
const { queryParams } = require('../../db/database');

const PUBLIC_DIR = path.join(__dirname, 'public');
const PORT = process.env.PORT || 3000;

function renderFile(filePath, replacements = {}) {
  let html = fs.readFileSync(filePath, 'utf8');
  for (const [k, v] of Object.entries(replacements)) {
    html = html.split(k).join(v);
  }
  return html;
}

async function checkhidden(userid) {
  try {
    const entry = await queryParams(
      `SELECT showleaderboard FROM settings WHERE user_id = ?`,
      [userid]
    );
    if (!entry.length) return false;
    return entry[0].showleaderboard === 0 || entry[0].showleaderboard === "0";
  } catch (e) {
    return false;
  }
}

function startServer() {
  const app = express();

  app.get('/', (req, res) => {
    const html = renderFile(path.join(PUBLIC_DIR, 'index.html'), {
      '__DEFAULT_PFP__': config.defaultpfp || '',
      '__DISCORD_INVITE__': (config.supportInvite || config.discordServer) || ''
    });
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.send(html);
  });

  app.get('/pricing.html', (req, res) => {
    res.sendFile(path.join(PUBLIC_DIR, 'pricing.html'));
  });

  app.get('/features.html', (req, res) => {
    res.sendFile(path.join(PUBLIC_DIR, 'features.html'));
  });

  app.get('/leaderboard.html', (req, res) => {
    res.sendFile(path.join(PUBLIC_DIR, 'leaderboard.html'));
  });

  app.get('/discord.html', (req, res) => {
    // user requested support redirect
    return res.redirect('https://discord.gg/mHpEkdPqSJ');
  });

  app.get('/login/callback', async (req, res) => {
    const { code } = req.query;
    
    console.log('[OAuth Callback] Received query:', req.query);
    console.log('[OAuth Callback] Expected redirect_uri:', process.env.REDIRECT_URI);

    if (!code) {
      return res.status(400).send(`Missing authorization code. Received: ${JSON.stringify(req.query)}`);
    }

    try {
      // Exchange code for access token
      const tokenResponse = await fetch('https://discord.com/api/oauth2/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          client_id: process.env.CLIENT_ID,
          client_secret: process.env.CLIENT_SECRET,
          code,
          grant_type: 'authorization_code',
          redirect_uri: process.env.REDIRECT_URI
        })
      });

      const tokenData = await tokenResponse.json();

      if (!tokenData.access_token) {
        console.error('Discord token error:', tokenData);
        return res.status(400).send('Failed to get access token from Discord');
      }

      // Get user info
      const userResponse = await fetch('https://discord.com/api/users/@me', {
        headers: { 'Authorization': `Bearer ${tokenData.access_token}` }
      });

      const user = await userResponse.json();

      if (!user.id) {
        console.error('Discord user error:', user);
        return res.status(400).send('Failed to get user info from Discord');
      }

      // Log successful authentication
      console.log(`[OAuth] User authenticated: ${user.username}#${user.discriminator} (${user.id})`);

      // TODO: Create session, store user data, etc.
      // For now, just redirect to home
      res.redirect('/?auth=success&user=' + encodeURIComponent(user.username));
    } catch (error) {
      console.error('[OAuth Callback Error]', error);
      res.status(500).send('Authentication failed: ' + error.message);
    }
  });

  app.get('/login.html', (req, res) => {
    const html = renderFile(path.join(PUBLIC_DIR, 'login.html'), {
      '__CLIENT_ID__': process.env.CLIENT_ID || '',
      '__REDIRECT_URI__': process.env.REDIRECT_URI || ''
    });
    res.send(html);
  });

  app.get('/api/leaderboard', async (req, res) => {
    try {
      const leaderboard = await queryParams(
        `SELECT user_id, amount FROM leaderboard ORDER BY amount DESC LIMIT 10`,
        []
      );

      const entries = [];
      for (let i = 0; i < leaderboard.length; i++) {
        const row = leaderboard[i];
        const hidden = await checkhidden(row.user_id);
        entries.push({
          rank: i + 1,
          name: hidden ? 'Hidden user' : row.user_id,
          accounts: row.amount
        });
      }

      res.json({
        status: 'success',
        data: entries,
        lastUpdated: new Date().toISOString()
      });
    } catch (error) {
      console.error('Leaderboard API error:', error);
      res.status(500).json({ status: 'error', message: 'Failed to fetch leaderboard' });
    }
  });

  // Serve static files AFTER route handlers so specific routes take precedence
  app.use(express.static(PUBLIC_DIR));

  app.listen(PORT, () => {
    console.log(`Webserver listening on port ${PORT}`);
  });
}

module.exports = { startServer };
