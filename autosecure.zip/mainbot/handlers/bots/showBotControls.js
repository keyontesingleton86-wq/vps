const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder
} = require("discord.js");

module.exports = async function showBotControls(botnumber, id, hidebuttons) {
  const embed = new EmbedBuilder()
    .setTitle("⚙️ AutoSecure — Bot Controls")
    .setDescription(
      "Use the controls below to manage this bot.\n\n" +
      "━━━━━━━━━━━━━━━━━━━━━━"
    )
    .setColor(0x7f9cff);

  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setLabel("Edit Bot")
      .setStyle(ButtonStyle.Primary)
      .setCustomId(`editbot|${botnumber}|${id}|${hidebuttons}`),
    new ButtonBuilder()
      .setLabel("Autosecure")
      .setStyle(ButtonStyle.Primary)
      .setCustomId(`editautosecure|${botnumber}|${id}`),
    new ButtonBuilder()
      .setLabel("Phisher")
      .setStyle(ButtonStyle.Primary)
      .setCustomId(`editphisher|${botnumber}|${id}`),
    new ButtonBuilder()
      .setLabel("Claim")
      .setStyle(ButtonStyle.Primary)
      .setCustomId(`claimusers|${botnumber}|${id}`)
  );

  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setLabel("Edit Embeds")
      .setStyle(ButtonStyle.Secondary)
      .setCustomId(`editembeds|${botnumber}|${id}`),
    new ButtonBuilder()
      .setLabel("Edit Buttons")
      .setStyle(ButtonStyle.Secondary)
      .setCustomId(`editbuttons|${botnumber}|${id}`),
    new ButtonBuilder()
      .setLabel("Edit Modals")
      .setStyle(ButtonStyle.Secondary)
      .setCustomId(`editmodals|${botnumber}|${id}`),
    new ButtonBuilder()
      .setLabel("Edit Presets")
      .setStyle(ButtonStyle.Secondary)
      .setCustomId(`editpresets|${botnumber}|${id}`)
  );

  const row3 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setLabel("Blacklisted Users")
      .setStyle(ButtonStyle.Success)
      .setCustomId(`blacklistedusers|${botnumber}|${id}`),
    new ButtonBuilder()
      .setLabel("Blacklisted Emails")
      .setStyle(ButtonStyle.Success)
      .setCustomId(`blacklistedemails|${botnumber}|${id}`)
  );

  if (!hidebuttons) {
    row3.addComponents(
      new ButtonBuilder()
        .setLabel("Download Config")
        .setStyle(ButtonStyle.Secondary)
        .setCustomId(`botsconfig|${botnumber}|${id}`)
    );
  }

  return {
    embeds: [embed],
    components: [row1, row2, row3],
    ephemeral: true
  };
};
