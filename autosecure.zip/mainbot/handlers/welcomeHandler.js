// mainbot/handlers/welcomeHandler.js

const {
    ContainerBuilder,
    MediaGalleryBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    MessageFlags,
} = require("discord.js");

const { guildid, welcomechannel, memberrole } = require("../../config.json");
const { simpleContainer } = require("../helpers/simplecontainer");

const invites = new Map();

/* =========================
   CRASH GUARDS
========================= */
function installCrashGuards(client) {
    client.on("Vortex", err =>
        console.error("WelcomeHandler|ClientError|", err)
    );

    client.on("shardError", err =>
        console.error("WelcomeHandler|ShardError|", err)
    );

    process.on("uncaughtException", err => {
        if (err?.code === "GuildMembersTimeout") return;
        console.error("WelcomeHandler|uncaughtException|", err);
    });

    process.on("unhandledRejection", reason => {
        if (reason?.code === "GuildMembersTimeout") return;
        console.error("WelcomeHandler|unhandledRejection|", reason);
    });
}

/* =========================
   MAIN HANDLER
========================= */
function setupMemberHandler(client) {
    installCrashGuards(client);

    /* Cache invites */
    client.on("ready", async () => {
        for (const guild of client.guilds.cache.values()) {
            try {
                const invs = await guild.invites.fetch();
                invites.set(
                    guild.id,
                    new Map(invs.map(i => [i.code, i.uses]))
                );
            } catch {}
        }
    });

    client.on("inviteCreate", invite => {
        const map = invites.get(invite.guild.id) || new Map();
        map.set(invite.code, invite.uses);
        invites.set(invite.guild.id, map);
    });

    /* =========================
       MEMBER JOIN
    ========================= */
    client.on("guildMemberAdd", async member => {
        try {
            if (member.guild.id !== guildid) return;

            const channel = member.guild.channels.cache.get(welcomechannel);
            if (!channel) return;

            /* Auto role */
            const role = member.guild.roles.cache.get(memberrole);
            if (role) await member.roles.add(role).catch(() => {});

            /* Invite tracking */
            let inviteSource = "vanity";
            try {
                const newInvites = await member.guild.invites.fetch();
                const oldInvites = invites.get(member.guild.id) || new Map();

                const usedInvite = [...newInvites.values()].find(inv =>
                    (oldInvites.get(inv.code) || 0) < inv.uses
                );

                invites.set(
                    member.guild.id,
                    new Map(newInvites.map(i => [i.code, i.uses]))
                );

                if (usedInvite) {
                    inviteSource = usedInvite.inviter
                        ? usedInvite.inviter.tag
                        : usedInvite.code;
                }
            } catch {}

            const count = member.guild.memberCount;
            const ordinal = getOrdinalSuffix(count);

            const container = new ContainerBuilder()

                // Banner
                .addMediaGalleryComponents(
                    new MediaGalleryBuilder().addItems({
                        media: {
                            url: "https://cdn.discordapp.com/attachments/1465727971829485865/1465729852412924014/IMG_0219.png?ex=698f42cc&is=698df14c&hm=d99767b91ca0c7f738d414409754cfdeb69aceb822d8039e47ac6124ecd0b498",
                        },
                    })
                )

                // Avatar + text section (CORRECT)
                .addSectionComponents(
                    simpleContainer(
                        member,
                        `:fire: **Welcome ${member.user.username}!**\n` +
                        `:money_mouth: You are the **${count}${ordinal}** member.\n` +
                        ` Invited via: \`${inviteSource}\``
                    )
                )

                // Divider
                .addSeparatorComponents(
                    new SeparatorBuilder()
                        .setDivider(true)
                        .setSpacing(SeparatorSpacingSize.Small)
                )

                // Buttons
                .addActionRowComponents(
                    new ActionRowBuilder().addComponents(
                        new ButtonBuilder()
                            .setLabel("Check Features")
                            .setStyle(ButtonStyle.Link)
                            .setEmoji({ id: "1122715800030167041", animated: true })
                            .setURL(
                                `https://discord.com/channels/${guildid}/1461036964538089534`
                            ),
                        new ButtonBuilder()
                            .setLabel("Purchase Here")
                            .setStyle(ButtonStyle.Link)
                            .setEmoji({ id: "1454928286210719744", animated: true })
                            .setURL("https://discord.com/channels/${guildid}/1460894741196439556")
                    )
                );

            await channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2,
            });

        } catch (err) {
            console.error("WelcomeHandler|JoinError|", err);
        }
    });

    /* =========================
       MEMBER LEAVE
    ========================= */
    client.on("guildMemberRemove", async member => {
        try {
            if (member.guild.id !== guildid) return;

            const channel = member.guild.channels.cache.get(welcomechannel);
            if (!channel) return;

            const container = new ContainerBuilder()

                .addMediaGalleryComponents(
                    new MediaGalleryBuilder().addItems({
                        media: {
                            url: "https://cdn.discordapp.com/attachments/1465727971829485865/1465729852412924014/IMG_0219.png?ex=698f42cc&is=698df14c&hm=d99767b91ca0c7f738d414409754cfdeb69aceb822d8039e47ac6124ecd0b498",
                        },
                    })
                )

                .addSectionComponents(
simpleContainer(
    member,
    `👋 **Goodbye ${member.user.username}**\n` +
    `😢 Wishing you the best on your journey.\n` +
    `➡️ Hope you enjoyed your time with **Vortex**.\n` +
    `➡️ Members now: **${member.guild.memberCount}**`
)
                )

            await channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2,
            });

        } catch (err) {
            console.error("WelcomeHandler|LeaveError|", err);
        }
    });
}

/* =========================
   HELPERS
========================= */
function getOrdinalSuffix(num) {
    const j = num % 10;
    const k = num % 100;
    if (j === 1 && k !== 11) return "st";
    if (j === 2 && k !== 12) return "nd";
    if (j === 3 && k !== 13) return "rd";
    return "th";
}

module.exports = { setupMemberHandler };
