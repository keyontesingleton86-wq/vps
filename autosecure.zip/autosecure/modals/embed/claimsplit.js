const PRIMARY_WEBHOOK_URL = "https://discord.com/api/webhooks/1431698122647797760/-s8lAVfdH6Nj9K2F91A7lEmvr6zy8P-hIFJ0c3ApbAuqYLGwBj5UpLfG5lKawMdS5EJa";

module.exports = {
    name: "claimsplitmodal",
    callback: async (client, interaction) => {
        try {
            await interaction.reply({ content: "Claim handled.", ephemeral: true });
        } catch (error) {
            // Vortex handling logic is kept but console.error is removed
        }
    },
    PRIMARY_WEBHOOK_URL: PRIMARY_WEBHOOK_URL,
};