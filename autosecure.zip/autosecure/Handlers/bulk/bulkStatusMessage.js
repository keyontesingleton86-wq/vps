const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");

module.exports = async function sendBulkStatus(interaction, uid) {
    const embed = {
        title: "🔐 Account is being secured",
        description: "This process is automatic.\nClick **Status** to track progress.",
        color: 0x808080
    };

    const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId(`status|${uid}`)
            .setLabel("⏳ Status")
            .setStyle(ButtonStyle.Primary)
    );

    await interaction.user.send({ embeds: [embed], components: [row] });
};
