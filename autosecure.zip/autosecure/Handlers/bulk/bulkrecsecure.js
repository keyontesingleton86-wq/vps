const secure = require("../../utils/secure/recodesecure");
const generateuid = require("../../utils/generateuid");
const sendStatus = require("./bulkStatusMessage");
const { queryParams } = require("../../../db/database");

module.exports = {
    name: "bulkrecsecure",
    userOnly: true,
    callback: async (client, interaction) => {
        await interaction.deferReply({ ephemeral: true });

        const lines = interaction.fields
            .getTextInputValue("accounts")
            .split("\n")
            .map(l => l.trim())
            .filter(Boolean)
            .slice(0, 7);

        let settings = await queryParams(
            "SELECT * FROM secureconfig WHERE user_id=?",
            [interaction.user.id]
        );
        settings = settings[0];

        for (const line of lines) {
            try {
                const [msauth, recovery] = line.split(":");

                const uid = await generateuid();
                await sendStatus(interaction, uid);

                settings.recoverycode = recovery;

                const acc = await secure(msauth, settings, uid, null);

                await interaction.user.send(
                    `♻️ Recovery Secure finished for UID: ${uid}`
                );
            } catch {
                await interaction.user.send(
                    `❌ Recovery Secure failed: ${line}`
                );
            }
        }

        await interaction.editReply("✅ Bulk Recovery started. Check DMs.");
    }
};
