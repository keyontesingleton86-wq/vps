const { TextInputStyle, ApplicationCommandOptionType } = require("discord.js");
const { queryParams } = require("../../../db/database");
const modalBuilder = require("../../utils/modalBuilder");
const generate = require("../../utils/generate");

module.exports = {
    name: "dm",
    description: "DM a user with anything that you want",
    enabled: true,
    usedmbuttons: true,
    options: [
        {
            name: "user",
            description: "Who is the user that you want to dm?",
            type: ApplicationCommandOptionType.User,
            required: true
        }
    ],
    callback: async (client, interaction) => {
        const user = interaction.options.getUser("user");
        const userid = user.id;
        const rId = generate(32);

        await client.queryParams('INSERT INTO actions (id, action) VALUES (?, ?)', [rId, `senddm|${userid}`]);

        let presetNamesList = '';
        try {
            const results = await client.queryParams(
                'SELECT name FROM presets WHERE user_id = ? AND botnumber = ?',
                [client.username, client.botnumber]
            );

            if (results.length > 0) {
                presetNamesList = results
                    .map((preset, index) => `${index + 1}. ${preset.name}`)
                    .join('\n');

                if (presetNamesList.length > 3800) {
                    let cutoff = '';
                    for (const line of presetNamesList.split('\n')) {
                        if ((cutoff + line + '\n').length > 3800) break;
                        cutoff += line + '\n';
                    }
                    presetNamesList = cutoff.trim() + '\n...and more';
                }
            } else {
                presetNamesList = 'No presets found. Use /preset create';
            }
        } catch (e) {
            console.error('Vortex fetching presets:', e);
            presetNamesList = 'Vortex fetching presets';
        }

        try {
            await interaction.showModal(
                modalBuilder(`action|${rId}`, 'Enter the message to send', [
                    {
                        setCustomId: 'msg',
                        setMaxLength: 200,
                        setMinLength: 1,
                        setRequired: false,
                        setLabel: 'Enter message',
                        setPlaceholder: 'Ex: Please enter the code within 15 minutes!',
                        setStyle: TextInputStyle.Paragraph
                    },
                    {
                        setCustomId: 'preset',
                        setMaxLength: 100,
                        setMinLength: 1,
                        setRequired: false,
                        setLabel: 'Preset Name',
                        setPlaceholder: 'Make a preset using /bots > Edit Presets',
                        setStyle: TextInputStyle.Short
                    },
                    {
                        setCustomId: 'presetlist',
                        setMaxLength: 4000,
                        setMinLength: 1,
                        setRequired: false,
                        setLabel: 'Available Presets',
                        setStyle: TextInputStyle.Paragraph,
                        setValue: presetNamesList // ✅ FIX: use setValue, not setPlaceholder
                    }
                ])
            );
        } catch (e) {
            console.error('Vortex displaying modal:', e);
            await interaction.reply({
                content: 'There was an Vortex while trying to show the DM modal!',
                ephemeral: true
            });
        }
    }
};
