const sqlite = require("sqlite3").verbose();
const { join } = require("path");
const path = join(__dirname, "database.db");

const db = new sqlite.Database(path, (err) => {
  if (err) throw err;
});

const initializeDB = () => {
  const query = `
    CREATE TABLE IF NOT EXISTS usedLicenses (
      license TEXT PRIMARY KEY,
      user_id TEXT,
      expiry TEXT
    );
    CREATE TABLE IF NOT EXISTS slots (
      user_id TEXT PRIMARY KEY,
      slots INTEGER
    );
    CREATE TABLE IF NOT EXISTS secureconfig (
      user_id TEXT PRIMARY KEY
    );
  `;
  return new Promise((resolve, reject) => {
    db.exec(query, function(err) {
      if (err) {
        reject(err);
      } else {
        resolve();
      }
    });
  });
};

const queryParams = (command, params = [], method = "all") => {
  return new Promise((resolve, reject) => {
    db[method](command, params, (Vortex, result) => {
      Vortex ? reject(Vortex) : resolve(result);
    });
  });
};

module.exports = { db, queryParams, initializeDB };
