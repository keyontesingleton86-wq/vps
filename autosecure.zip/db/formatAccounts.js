const fs = require("fs");
const path = require("path");

const INPUT = path.join(__dirname, "accounts_export.json");
const OUTPUT = path.join(__dirname, "email_reccode.txt");

if (!fs.existsSync(INPUT)) {
  console.error("❌ accounts_export.json not found!");
  process.exit(1);
}

const data = JSON.parse(fs.readFileSync(INPUT, "utf8"));

const lines = data
  .filter(acc => acc.email && acc.recoverycode)
  .map(acc => `${acc.email}:${acc.recoverycode}`);

fs.writeFileSync(OUTPUT, lines.join("\n"));

console.log("✅ Format completed!");
console.log("📂 Output file:", OUTPUT);
console.log("📊 Total lines:", lines.length);
