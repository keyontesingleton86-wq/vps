const sqlite3 = require("sqlite3").verbose();
const fs = require("fs");
const path = require("path");

const DB_PATH = path.join(__dirname, "database.db");
const OUTPUT_FILE = path.join(__dirname, "accounts_export.json");

console.log("📦 Exporting accounts from:", DB_PATH);

// Open database
const db = new sqlite3.Database(DB_PATH, sqlite3.OPEN_READONLY, err => {
  if (err) {
    console.error("❌ Failed to open database:", err.message);
    process.exit(1);
  }
});

// 🔴 CHANGE THIS if your table name is different
const ACCOUNTS_TABLE = "accounts";

db.all(`SELECT * FROM ${ACCOUNTS_TABLE}`, [], (err, rows) => {
  if (err) {
    console.error("❌ Query failed:", err.message);
    process.exit(1);
  }

  fs.writeFileSync(OUTPUT_FILE, JSON.stringify(rows, null, 2));

  console.log("✅ Export completed successfully!");
  console.log("📂 Output file:", OUTPUT_FILE);
  console.log("📊 Total rows exported:", rows.length);

  db.close();
});
